# testpdf

## Commands

```shell
dotnet build
dotnet watch
dotnet run
```

## Docker

```shell
docker build -t company/testpdf .
docker run --name testpdf -d -p 5252:80 company/testpdf
```

## Endspoints

- http://localhost:5252/WeatherForecast